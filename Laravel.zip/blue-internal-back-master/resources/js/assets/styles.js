import "./layout/styles/layout/layout.scss";
import "primevue/resources/primevue.min.css";
import "primeflex/primeflex.scss";

/* Demos */
import './demo/styles/flags/flags.css';
import './demo/styles/badges.scss';