<template>
    <pre class="border-round surface-ground text-900 p-5 overflow-auto">
        <code class="-mt-4 p-0 line-height-3 block" style="font-family: monaco, Consolas, 'Lucida Console', monospace"><slot></slot></code></pre>
</template>