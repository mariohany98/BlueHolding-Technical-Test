<template>
    <div className="card">
        <span>{{$t('Welcome to')}}</span>
        <h5>{{$t('Intranet Dashboard')}}</h5>
        <!-- <p>{{$t('loremIpsum')}}</p> -->
    </div>
</template>

<script>
export default {};
</script>