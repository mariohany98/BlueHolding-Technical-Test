export default {
    user(state) {
        return state.user;
    }, //end of getting current user data
    isLoggedIn(state) {
        return state.isLoggedIn;
    }
};
