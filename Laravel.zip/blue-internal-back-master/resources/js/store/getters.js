export default {
    getLocale(state) {
        return state.locale;
    },
    getEditorOptions(state) {
        return state.editorOptions;
    },
    isRtl(state) {
        return state.rtl;
    },
};
