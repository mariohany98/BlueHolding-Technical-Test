export default {
  backgroundColor: `transparent`,
  color: `var(--Text)`,
  textDecoration: 'underline',
  fontWeight: '700'
};