import Home from "@/compnents/home/home";
import Layout from "../compnents/shared/layout";

export default function Index() {

  return (
    <Layout>
      <Home />
    </Layout>
  );
}
