import React from "react";
import Layout from "@/compnents/shared/layout";
import Post from "../../compnents/Post/Index"

export default function Index() {
  return (
    <Layout>
        <Post/>
    </Layout>
  );
}
