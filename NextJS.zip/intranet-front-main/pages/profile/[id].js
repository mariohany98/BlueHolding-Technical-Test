import Layout from "@/compnents/shared/layout";
import Profile from "@/compnents/profile/profile";

export default function profile_ID() {
    return (
        <Layout>
            {/* <h1>User Profile Component</h1> */}
            <Profile />
        </Layout>
    )
}