import Layout from '@/compnents/shared/layout'
import React from 'react'
import Profile from '../../compnents/profile/profile'

export default function Index() {
  return (
    <Layout>
      <Profile />
    </Layout>
  )
}